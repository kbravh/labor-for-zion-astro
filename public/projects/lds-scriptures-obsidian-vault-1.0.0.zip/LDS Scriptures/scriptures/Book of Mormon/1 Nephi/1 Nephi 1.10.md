And he also saw twelve others following him, and their brightness did exceed that of the stars in the firmament. ^verse

---

