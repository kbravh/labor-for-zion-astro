And it came to pass that as he read, he was filled with the Spirit of the Lord. ^verse

---

