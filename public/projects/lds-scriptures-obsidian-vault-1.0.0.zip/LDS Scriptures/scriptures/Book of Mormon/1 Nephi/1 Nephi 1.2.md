Yea, I make a record in the language of my father, which consists of the learning of the Jews and the language of the Egyptians. ^verse

---

