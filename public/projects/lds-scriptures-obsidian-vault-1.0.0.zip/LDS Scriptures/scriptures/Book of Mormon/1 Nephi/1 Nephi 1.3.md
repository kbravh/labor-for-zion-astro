And I know that the record which I make is true; and I make it with mine own hand; and I make it according to my knowledge. ^verse

---

