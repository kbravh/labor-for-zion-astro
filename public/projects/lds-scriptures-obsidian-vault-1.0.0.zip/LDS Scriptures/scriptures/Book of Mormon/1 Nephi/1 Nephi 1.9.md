And it came to pass that he saw One descending out of the midst of heaven, and he beheld that his luster was above that of the sun at noon-day. ^verse

---

