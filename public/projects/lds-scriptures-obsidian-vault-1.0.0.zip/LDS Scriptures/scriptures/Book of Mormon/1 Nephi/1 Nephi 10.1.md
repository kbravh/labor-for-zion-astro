And now I, Nephi, proceed to give an account upon these plates of my proceedings, and my reign and ministry; wherefore, to proceed with mine account, I must speak somewhat of the things of my father, and also of my brethren. ^verse

---

