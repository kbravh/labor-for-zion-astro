Yea, even my father spake much concerning the Gentiles, and also concerning the house of Israel, that they should be compared like unto an olive tree, whose branches should be broken off and should be scattered upon all the face of the earth. ^verse

---

