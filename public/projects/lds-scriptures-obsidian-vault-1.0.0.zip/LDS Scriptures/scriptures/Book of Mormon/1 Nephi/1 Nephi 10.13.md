Wherefore, he said it must needs be that we should be led with one accord into the land of promise, unto the fulfilling of the word of the Lord, that we should be scattered upon all the face of the earth. ^verse

---

