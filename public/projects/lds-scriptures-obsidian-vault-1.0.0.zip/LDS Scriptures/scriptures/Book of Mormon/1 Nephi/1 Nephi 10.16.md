And all these things, of which I have spoken, were done as my father dwelt in a tent, in the valley of Lemuel. ^verse

---

