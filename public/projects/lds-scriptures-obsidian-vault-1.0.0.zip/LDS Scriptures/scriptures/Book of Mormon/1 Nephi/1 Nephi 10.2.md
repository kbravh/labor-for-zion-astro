For behold, it came to pass after my father had made an end of speaking the words of his dream, and also of exhorting them to all diligence, he spake unto them concerning the Jews— ^verse

---

