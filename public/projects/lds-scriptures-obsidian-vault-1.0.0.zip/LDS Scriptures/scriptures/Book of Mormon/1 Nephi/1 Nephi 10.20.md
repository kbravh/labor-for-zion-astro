Therefore remember, O man, for all thy doings thou shalt be brought into judgment. ^verse

---

