And the Holy Ghost giveth authority that I should speak these things, and deny them not. ^verse

---

