And he also spake concerning the prophets, how great a number had testified of these things, concerning this Messiah, of whom he had spoken, or this Redeemer of the world. ^verse

---

