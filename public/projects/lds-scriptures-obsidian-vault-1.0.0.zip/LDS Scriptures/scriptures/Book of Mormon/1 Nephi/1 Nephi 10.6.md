Wherefore, all mankind were in a lost and in a fallen state, and ever would be save they should rely on this Redeemer. ^verse

---

