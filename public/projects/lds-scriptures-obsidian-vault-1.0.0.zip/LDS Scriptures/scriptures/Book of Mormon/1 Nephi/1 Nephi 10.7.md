And he spake also concerning a prophet who should come before the Messiah, to prepare the way of the Lord— ^verse

---

