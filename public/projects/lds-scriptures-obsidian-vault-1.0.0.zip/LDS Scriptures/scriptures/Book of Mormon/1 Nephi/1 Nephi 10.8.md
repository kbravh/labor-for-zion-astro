Yea, even he should go forth and cry in the wilderness: Prepare ye the way of the Lord, and make his paths straight; for there standeth one among you whom ye know not; and he is mightier than I, whose shoe’s latchet I am not worthy to unloose. And much spake my father concerning this thing. ^verse

---

