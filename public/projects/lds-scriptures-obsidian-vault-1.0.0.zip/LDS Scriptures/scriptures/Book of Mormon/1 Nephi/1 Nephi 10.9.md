And my father said he should baptize in Bethabara, beyond Jordan; and he also said he should baptize with water; even that he should baptize the Messiah with water. ^verse

---

