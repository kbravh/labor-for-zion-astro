
[[1 Nephi 9|Previous chapter]]

Lehi predicts that the Jews will be taken captive by the Babylonians—He tells of the coming among the Jews of a Messiah, a Savior, a Redeemer—Lehi tells also of the coming of the one who should baptize the Lamb of God—Lehi tells of the death and resurrection of the Messiah—He compares the scattering and gathering of Israel to an olive tree—Nephi speaks of the Son of God, of the gift of the Holy Ghost, and of the need for righteousness. About 600–592 B.C.

###### 1 ![[1 Nephi 10.1#^verse]]
###### 2 ![[1 Nephi 10.2#^verse]]
###### 3 ![[1 Nephi 10.3#^verse]]
###### 4 ![[1 Nephi 10.4#^verse]]
###### 5 ![[1 Nephi 10.5#^verse]]
###### 6 ![[1 Nephi 10.6#^verse]]
###### 7 ![[1 Nephi 10.7#^verse]]
###### 8 ![[1 Nephi 10.8#^verse]]
###### 9 ![[1 Nephi 10.9#^verse]]
###### 10 ![[1 Nephi 10.10#^verse]]
###### 11 ![[1 Nephi 10.11#^verse]]
###### 12 ![[1 Nephi 10.12#^verse]]
###### 13 ![[1 Nephi 10.13#^verse]]
###### 14 ![[1 Nephi 10.14#^verse]]
###### 15 ![[1 Nephi 10.15#^verse]]
###### 16 ![[1 Nephi 10.16#^verse]]
###### 17 ![[1 Nephi 10.17#^verse]]
###### 18 ![[1 Nephi 10.18#^verse]]
###### 19 ![[1 Nephi 10.19#^verse]]
###### 20 ![[1 Nephi 10.20#^verse]]
###### 21 ![[1 Nephi 10.21#^verse]]
###### 22 ![[1 Nephi 10.22#^verse]]

[[1 Nephi 11|Next chapter]]