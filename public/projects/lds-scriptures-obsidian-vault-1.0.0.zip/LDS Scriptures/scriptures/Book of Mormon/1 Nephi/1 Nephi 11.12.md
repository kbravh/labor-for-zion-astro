And it came to pass that he said unto me: Look! And I looked as if to look upon him, and I saw him not; for he had gone from before my presence. ^verse

---

