And I said unto him: A virgin, most beautiful and fair above all other virgins. ^verse

---

