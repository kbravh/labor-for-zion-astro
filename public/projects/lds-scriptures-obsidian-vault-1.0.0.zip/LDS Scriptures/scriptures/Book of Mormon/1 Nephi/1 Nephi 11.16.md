And he said unto me: Knowest thou the condescension of God? ^verse

---

