And I said unto him: I know that he loveth his children; nevertheless, I do not know the meaning of all things. ^verse

---

