And he said unto me: Behold, the virgin whom thou seest is the mother of the Son of God, after the manner of the flesh. ^verse

---

