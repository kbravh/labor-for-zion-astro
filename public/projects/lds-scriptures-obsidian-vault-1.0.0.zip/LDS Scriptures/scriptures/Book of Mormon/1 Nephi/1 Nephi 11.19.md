And it came to pass that I beheld that she was carried away in the Spirit; and after she had been carried away in the Spirit for the space of a time the angel spake unto me, saying: Look! ^verse

---

