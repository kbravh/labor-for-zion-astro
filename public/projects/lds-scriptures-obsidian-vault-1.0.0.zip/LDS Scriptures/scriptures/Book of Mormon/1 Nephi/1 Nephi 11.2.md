And the Spirit said unto me: Behold, what desirest thou? ^verse

---

