And I looked and beheld the virgin again, bearing a child in her arms. ^verse

---

