And he spake unto me, saying: Yea, and the most joyous to the soul. ^verse

---

