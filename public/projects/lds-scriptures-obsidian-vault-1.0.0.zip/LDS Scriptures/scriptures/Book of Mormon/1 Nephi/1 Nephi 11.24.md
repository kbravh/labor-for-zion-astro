And after he had said these words, he said unto me: Look! And I looked, and I beheld the Son of God going forth among the children of men; and I saw many fall down at his feet and worship him. ^verse

---

