And the angel said unto me again: Look and behold the condescension of God! ^verse

---

