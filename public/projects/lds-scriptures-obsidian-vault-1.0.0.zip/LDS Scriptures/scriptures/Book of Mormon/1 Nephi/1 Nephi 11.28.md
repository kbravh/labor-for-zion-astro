And I beheld that he went forth ministering unto the people, in power and great glory; and the multitudes were gathered together to hear him; and I beheld that they cast him out from among them. ^verse

---

