And I also beheld twelve others following him. And it came to pass that they were carried away in the Spirit from before my face, and I saw them not. ^verse

---

