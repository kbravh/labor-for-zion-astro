And I said: I desire to behold the things which my father saw. ^verse

---

