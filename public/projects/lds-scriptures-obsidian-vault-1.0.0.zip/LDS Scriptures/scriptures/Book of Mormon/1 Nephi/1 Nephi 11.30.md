And it came to pass that the angel spake unto me again, saying: Look! And I looked, and I beheld the heavens open again, and I saw angels descending upon the children of men; and they did minister unto them. ^verse

---

