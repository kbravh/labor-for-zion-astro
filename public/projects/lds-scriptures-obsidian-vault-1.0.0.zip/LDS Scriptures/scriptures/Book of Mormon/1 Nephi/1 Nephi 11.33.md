And I, Nephi, saw that he was lifted up upon the cross and slain for the sins of the world. ^verse

---

