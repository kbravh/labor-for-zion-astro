And the multitude of the earth was gathered together; and I beheld that they were in a large and spacious building, like unto the building which my father saw. And the angel of the Lord spake unto me again, saying: Behold the world and the wisdom thereof; yea, behold the house of Israel hath gathered together to fight against the twelve apostles of the Lamb. ^verse

---

