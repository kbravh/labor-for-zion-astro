And it came to pass that I saw and bear record, that the great and spacious building was the pride of the world; and it fell, and the fall thereof was exceedingly great. And the angel of the Lord spake unto me again, saying: Thus shall be the destruction of all nations, kindreds, tongues, and people, that shall fight against the twelve apostles of the Lamb. ^verse

---

