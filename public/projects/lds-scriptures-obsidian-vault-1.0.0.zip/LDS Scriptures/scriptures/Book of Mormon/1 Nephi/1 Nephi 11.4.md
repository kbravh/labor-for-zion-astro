And the Spirit said unto me: Believest thou that thy father saw the tree of which he hath spoken? ^verse

---

