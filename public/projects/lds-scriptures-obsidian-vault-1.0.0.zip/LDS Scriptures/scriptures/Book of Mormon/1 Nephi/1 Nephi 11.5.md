And I said: Yea, thou knowest that I believe all the words of my father. ^verse

---

