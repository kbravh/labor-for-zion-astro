And when I had spoken these words, the Spirit cried with a loud voice, saying: Hosanna to the Lord, the most high God; for he is God over all the earth, yea, even above all. And blessed art thou, Nephi, because thou believest in the Son of the most high God; wherefore, thou shalt behold the things which thou hast desired. ^verse

---

