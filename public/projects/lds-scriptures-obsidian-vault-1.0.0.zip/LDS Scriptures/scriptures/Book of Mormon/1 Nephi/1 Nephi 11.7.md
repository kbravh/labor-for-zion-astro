And behold this thing shall be given unto thee for a sign, that after thou hast beheld the tree which bore the fruit which thy father tasted, thou shalt also behold a man descending out of heaven, and him shall ye witness; and after ye have witnessed him ye shall bear record that it is the Son of God. ^verse

---

