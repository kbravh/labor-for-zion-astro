And it came to pass that the Spirit said unto me: Look! And I looked and beheld a tree; and it was like unto the tree which my father had seen; and the beauty thereof was far beyond, yea, exceeding of all beauty; and the whiteness thereof did exceed the whiteness of the driven snow. ^verse

---

