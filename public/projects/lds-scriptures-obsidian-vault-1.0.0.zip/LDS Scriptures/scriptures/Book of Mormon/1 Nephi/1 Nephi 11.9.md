And it came to pass after I had seen the tree, I said unto the Spirit: I behold thou hast shown unto me the tree which is precious above all. ^verse

---

