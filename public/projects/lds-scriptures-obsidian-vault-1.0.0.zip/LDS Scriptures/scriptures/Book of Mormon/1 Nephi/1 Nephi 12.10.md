And these twelve ministers whom thou beholdest shall judge thy seed. And, behold, they are righteous forever; for because of their faith in the Lamb of God their garments are made white in his blood. ^verse

---

