And the angel said unto me: Look! And I looked, and beheld three generations pass away in righteousness; and their garments were white even like unto the Lamb of God. And the angel said unto me: These are made white in the blood of the Lamb, because of their faith in him. ^verse

---

