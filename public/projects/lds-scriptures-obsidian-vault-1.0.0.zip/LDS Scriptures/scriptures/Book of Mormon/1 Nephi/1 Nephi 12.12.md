And I, Nephi, also saw many of the fourth generation who passed away in righteousness. ^verse

---

