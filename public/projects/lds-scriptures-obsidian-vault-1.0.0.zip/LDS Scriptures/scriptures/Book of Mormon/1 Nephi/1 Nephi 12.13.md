And it came to pass that I saw the multitudes of the earth gathered together. ^verse

---

