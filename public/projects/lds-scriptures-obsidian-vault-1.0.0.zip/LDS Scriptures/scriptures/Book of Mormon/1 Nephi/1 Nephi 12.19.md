And while the angel spake these words, I beheld and saw that the seed of my brethren did contend against my seed, according to the word of the angel; and because of the pride of my seed, and the temptations of the devil, I beheld that the seed of my brethren did overpower the people of my seed. ^verse

---

