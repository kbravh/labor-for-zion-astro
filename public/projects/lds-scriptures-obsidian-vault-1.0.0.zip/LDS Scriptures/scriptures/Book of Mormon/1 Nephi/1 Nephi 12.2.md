And it came to pass that I beheld multitudes gathered together to battle, one against the other; and I beheld wars, and rumors of wars, and great slaughters with the sword among my people. ^verse

---

