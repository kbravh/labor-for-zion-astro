And it came to pass that I beheld, and saw the people of the seed of my brethren that they had overcome my seed; and they went forth in multitudes upon the face of the land. ^verse

---

