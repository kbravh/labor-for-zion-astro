And I saw them gathered together in multitudes; and I saw wars and rumors of wars among them; and in wars and rumors of wars I saw many generations pass away. ^verse

---

