And the angel said unto me: Behold these shall dwindle in unbelief. ^verse

---

