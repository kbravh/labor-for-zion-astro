And it came to pass that I beheld many generations pass away, after the manner of wars and contentions in the land; and I beheld many cities, yea, even that I did not number them. ^verse

---

