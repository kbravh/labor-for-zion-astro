And it came to pass that I saw a mist of darkness on the face of the land of promise; and I saw lightnings, and I heard thunderings, and earthquakes, and all manner of tumultuous noises; and I saw the earth and the rocks, that they rent; and I saw mountains tumbling into pieces; and I saw the plains of the earth, that they were broken up; and I saw many cities that they were sunk; and I saw many that they were burned with fire; and I saw many that did tumble to the earth, because of the quaking thereof. ^verse

---

