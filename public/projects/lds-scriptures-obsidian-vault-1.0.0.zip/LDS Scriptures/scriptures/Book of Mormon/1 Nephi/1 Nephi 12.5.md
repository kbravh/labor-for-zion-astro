And it came to pass after I saw these things, I saw the vapor of darkness, that it passed from off the face of the earth; and behold, I saw multitudes who had not fallen because of the great and terrible judgments of the Lord. ^verse

---

