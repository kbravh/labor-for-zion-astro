And I saw the heavens open, and the Lamb of God descending out of heaven; and he came down and showed himself unto them. ^verse

---

