And I also saw and bear record that the Holy Ghost fell upon twelve others; and they were ordained of God, and chosen. ^verse

---

