And the angel spake unto me, saying: Behold the twelve disciples of the Lamb, who are chosen to minister unto thy seed. ^verse

---

