And he said unto me: Thou rememberest the twelve apostles of the Lamb? Behold they are they who shall judge the twelve tribes of Israel; wherefore, the twelve ministers of thy seed shall be judged of them; for ye are of the house of Israel. ^verse

---

