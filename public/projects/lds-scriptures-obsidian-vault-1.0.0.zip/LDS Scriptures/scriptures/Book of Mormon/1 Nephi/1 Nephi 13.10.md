And it came to pass that I looked and beheld many waters; and they divided the Gentiles from the seed of my brethren. ^verse

---

