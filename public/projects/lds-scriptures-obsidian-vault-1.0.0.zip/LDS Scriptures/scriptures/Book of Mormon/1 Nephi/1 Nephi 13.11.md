And it came to pass that the angel said unto me: Behold the wrath of God is upon the seed of thy brethren. ^verse

---

