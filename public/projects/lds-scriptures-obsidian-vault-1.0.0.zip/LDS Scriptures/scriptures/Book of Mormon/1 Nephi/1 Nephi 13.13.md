And it came to pass that I beheld the Spirit of God, that it wrought upon other Gentiles; and they went forth out of captivity, upon the many waters. ^verse

---

