And it came to pass that I beheld many multitudes of the Gentiles upon the land of promise; and I beheld the wrath of God, that it was upon the seed of my brethren; and they were scattered before the Gentiles and were smitten. ^verse

---

