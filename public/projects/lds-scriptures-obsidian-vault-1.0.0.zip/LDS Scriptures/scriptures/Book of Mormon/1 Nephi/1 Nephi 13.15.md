And I beheld the Spirit of the Lord, that it was upon the Gentiles, and they did prosper and obtain the land for their inheritance; and I beheld that they were white, and exceedingly fair and beautiful, like unto my people before they were slain. ^verse

---

