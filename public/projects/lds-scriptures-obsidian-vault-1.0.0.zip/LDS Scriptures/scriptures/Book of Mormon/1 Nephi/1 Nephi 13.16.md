And it came to pass that I, Nephi, beheld that the Gentiles who had gone forth out of captivity did humble themselves before the Lord; and the power of the Lord was with them. ^verse

---

