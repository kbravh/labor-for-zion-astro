And I beheld that their mother Gentiles were gathered together upon the waters, and upon the land also, to battle against them. ^verse

---

