And I beheld that the power of God was with them, and also that the wrath of God was upon all those that were gathered together against them to battle. ^verse

---

