And I, Nephi, beheld that the Gentiles that had gone out of captivity were delivered by the power of God out of the hands of all other nations. ^verse

---

