And the angel said unto me: What beholdest thou? And I said: I behold many nations and kingdoms. ^verse

---

