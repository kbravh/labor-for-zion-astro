And it came to pass that I, Nephi, beheld that they did prosper in the land; and I beheld a book, and it was carried forth among them. ^verse

---

