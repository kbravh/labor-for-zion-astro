And the angel said unto me: Knowest thou the meaning of the book? ^verse

---

