And I said unto him: I know not. ^verse

---

