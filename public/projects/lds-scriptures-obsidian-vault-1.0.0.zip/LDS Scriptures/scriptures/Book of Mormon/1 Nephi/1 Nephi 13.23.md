And he said: Behold it proceedeth out of the mouth of a Jew. And I, Nephi, beheld it; and he said unto me: The book that thou beholdest is a record of the Jews, which contains the covenants of the Lord, which he hath made unto the house of Israel; and it also containeth many of the prophecies of the holy prophets; and it is a record like unto the engravings which are upon the plates of brass, save there are not so many; nevertheless, they contain the covenants of the Lord, which he hath made unto the house of Israel; wherefore, they are of great worth unto the Gentiles. ^verse

---

