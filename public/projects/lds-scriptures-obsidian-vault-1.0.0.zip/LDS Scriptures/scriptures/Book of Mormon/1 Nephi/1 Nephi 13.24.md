And the angel of the Lord said unto me: Thou hast beheld that the book proceeded forth from the mouth of a Jew; and when it proceeded forth from the mouth of a Jew it contained the fulness of the gospel of the Lord, of whom the twelve apostles bear record; and they bear record according to the truth which is in the Lamb of God. ^verse

---

