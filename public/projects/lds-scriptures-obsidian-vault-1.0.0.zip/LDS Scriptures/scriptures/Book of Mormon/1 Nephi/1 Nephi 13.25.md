Wherefore, these things go forth from the Jews in purity unto the Gentiles, according to the truth which is in God. ^verse

---

