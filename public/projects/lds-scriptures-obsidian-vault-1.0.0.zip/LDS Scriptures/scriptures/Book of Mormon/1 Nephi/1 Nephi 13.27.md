And all this have they done that they might pervert the right ways of the Lord, that they might blind the eyes and harden the hearts of the children of men. ^verse

---

