And he said unto me: These are the nations and kingdoms of the Gentiles. ^verse

---

