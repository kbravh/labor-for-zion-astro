Nevertheless, thou beholdest that the Gentiles who have gone forth out of captivity, and have been lifted up by the power of God above all other nations, upon the face of the land which is choice above all other lands, which is the land that the Lord God hath covenanted with thy father that his seed should have for the land of their inheritance; wherefore, thou seest that the Lord God will not suffer that the Gentiles will utterly destroy the mixture of thy seed, which are among thy brethren. ^verse

---

