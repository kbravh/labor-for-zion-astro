Neither will he suffer that the Gentiles shall destroy the seed of thy brethren. ^verse

---

