Neither will the Lord God suffer that the Gentiles shall forever remain in that awful state of blindness, which thou beholdest they are in, because of the plain and most precious parts of the gospel of the Lamb which have been kept back by that abominable church, whose formation thou hast seen. ^verse

---

