Wherefore saith the Lamb of God: I will be merciful unto the Gentiles, unto the visiting of the remnant of the house of Israel in great judgment. ^verse

---

