And in them shall be written my gospel, saith the Lamb, and my rock and my salvation. ^verse

---

