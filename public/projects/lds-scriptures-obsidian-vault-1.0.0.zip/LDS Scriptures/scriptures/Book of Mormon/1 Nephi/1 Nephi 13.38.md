And it came to pass that I beheld the remnant of the seed of my brethren, and also the book of the Lamb of God, which had proceeded forth from the mouth of the Jew, that it came forth from the Gentiles unto the remnant of the seed of my brethren. ^verse

---

