And it came to pass that I saw among the nations of the Gentiles the formation of a great church. ^verse

---

