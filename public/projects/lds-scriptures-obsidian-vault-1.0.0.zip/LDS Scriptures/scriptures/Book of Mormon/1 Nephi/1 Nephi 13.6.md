And it came to pass that I beheld this great and abominable church; and I saw the devil that he was the founder of it. ^verse

---

