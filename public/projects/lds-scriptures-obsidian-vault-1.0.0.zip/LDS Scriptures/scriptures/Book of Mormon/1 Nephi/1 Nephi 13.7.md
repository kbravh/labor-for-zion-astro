And I also saw gold, and silver, and silks, and scarlets, and fine-twined linen, and all manner of precious clothing; and I saw many harlots. ^verse

---

