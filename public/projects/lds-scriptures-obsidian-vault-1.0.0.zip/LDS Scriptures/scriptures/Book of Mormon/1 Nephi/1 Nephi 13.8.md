And the angel spake unto me, saying: Behold the gold, and the silver, and the silks, and the scarlets, and the fine-twined linen, and the precious clothing, and the harlots, are the desires of this great and abominable church. ^verse

---

