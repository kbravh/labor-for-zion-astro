And also for the praise of the world do they destroy the saints of God, and bring them down into captivity. ^verse

---

