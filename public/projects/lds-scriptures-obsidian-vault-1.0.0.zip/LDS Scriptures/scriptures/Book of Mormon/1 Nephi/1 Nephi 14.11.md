And it came to pass that I looked and beheld the whore of all the earth, and she sat upon many waters; and she had dominion over all the earth, among all nations, kindreds, tongues, and people. ^verse

---

