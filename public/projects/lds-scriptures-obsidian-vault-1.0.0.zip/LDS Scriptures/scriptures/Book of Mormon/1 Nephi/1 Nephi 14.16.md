And as there began to be wars and rumors of wars among all the nations which belonged to the mother of abominations, the angel spake unto me, saying: Behold, the wrath of God is upon the mother of harlots; and behold, thou seest all these things— ^verse

---

