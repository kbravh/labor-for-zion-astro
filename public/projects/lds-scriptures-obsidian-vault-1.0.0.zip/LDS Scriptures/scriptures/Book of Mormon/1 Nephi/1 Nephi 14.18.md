And it came to pass that the angel spake unto me, saying: Look! ^verse

---

