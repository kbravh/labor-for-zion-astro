And I looked and beheld a man, and he was dressed in a white robe. ^verse

---

