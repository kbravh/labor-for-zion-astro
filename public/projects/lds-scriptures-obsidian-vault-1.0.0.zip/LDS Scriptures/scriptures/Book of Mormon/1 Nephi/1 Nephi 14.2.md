And harden not their hearts against the Lamb of God, they shall be numbered among the seed of thy father; yea, they shall be numbered among the house of Israel; and they shall be a blessed people upon the promised land forever; they shall be no more brought down into captivity; and the house of Israel shall no more be confounded. ^verse

---

