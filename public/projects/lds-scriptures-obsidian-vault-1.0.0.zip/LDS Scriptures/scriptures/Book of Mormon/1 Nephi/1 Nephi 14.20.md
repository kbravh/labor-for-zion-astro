And the angel said unto me: Behold one of the twelve apostles of the Lamb. ^verse

---

