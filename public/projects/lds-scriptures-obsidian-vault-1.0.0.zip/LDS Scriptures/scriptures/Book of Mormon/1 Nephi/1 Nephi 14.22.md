And he shall also write concerning the end of the world. ^verse

---

