And behold, the things which this apostle of the Lamb shall write are many things which thou hast seen; and behold, the remainder shalt thou see. ^verse

---

