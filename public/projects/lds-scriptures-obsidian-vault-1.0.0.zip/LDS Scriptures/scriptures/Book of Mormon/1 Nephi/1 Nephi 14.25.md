But the things which thou shalt see hereafter thou shalt not write; for the Lord God hath ordained the apostle of the Lamb of God that he should write them. ^verse

---

