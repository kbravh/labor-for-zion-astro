And also others who have been, to them hath he shown all things, and they have written them; and they are sealed up to come forth in their purity, according to the truth which is in the Lamb, in the own due time of the Lord, unto the house of Israel. ^verse

---

