And I, Nephi, heard and bear record, that the name of the apostle of the Lamb was John, according to the word of the angel. ^verse

---

