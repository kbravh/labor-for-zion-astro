And behold, I, Nephi, am forbidden that I should write the remainder of the things which I saw and heard; wherefore the things which I have written sufficeth me; and I have written but a small part of the things which I saw. ^verse

---

