And I bear record that I saw the things which my father saw, and the angel of the Lord did make them known unto me. ^verse

---

