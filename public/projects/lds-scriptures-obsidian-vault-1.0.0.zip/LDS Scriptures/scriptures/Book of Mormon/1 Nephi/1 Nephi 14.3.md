And that great pit, which hath been digged for them by that great and abominable church, which was founded by the devil and his children, that he might lead away the souls of men down to hell—yea, that great pit which hath been digged for the destruction of men shall be filled by those who digged it, unto their utter destruction, saith the Lamb of God; not the destruction of the soul, save it be the casting of it into that hell which hath no end. ^verse

---

