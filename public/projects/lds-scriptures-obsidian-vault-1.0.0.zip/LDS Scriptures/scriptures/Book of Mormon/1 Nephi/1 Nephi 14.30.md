And now I make an end of speaking concerning the things which I saw while I was carried away in the Spirit; and if all the things which I saw are not written, the things which I have written are true. And thus it is. Amen. ^verse

---

