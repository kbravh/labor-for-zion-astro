For behold, this is according to the captivity of the devil, and also according to the justice of God, upon all those who will work wickedness and abomination before him. ^verse

---

