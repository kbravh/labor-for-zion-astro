And it came to pass that the angel spake unto me, Nephi, saying: Thou hast beheld that if the Gentiles repent it shall be well with them; and thou also knowest concerning the covenants of the Lord unto the house of Israel; and thou also hast heard that whoso repenteth not must perish. ^verse

---

