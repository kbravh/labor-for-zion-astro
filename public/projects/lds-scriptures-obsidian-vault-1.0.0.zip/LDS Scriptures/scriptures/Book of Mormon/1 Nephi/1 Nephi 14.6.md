Therefore, wo be unto the Gentiles if it so be that they harden their hearts against the Lamb of God. ^verse

---

