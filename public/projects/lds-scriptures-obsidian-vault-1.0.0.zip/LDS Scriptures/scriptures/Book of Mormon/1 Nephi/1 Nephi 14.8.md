And it came to pass that when the angel had spoken these words, he said unto me: Rememberest thou the covenants of the Father unto the house of Israel? I said unto him, Yea. ^verse

---

