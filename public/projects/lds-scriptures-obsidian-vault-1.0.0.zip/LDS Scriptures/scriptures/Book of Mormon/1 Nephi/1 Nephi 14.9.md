And it came to pass that he said unto me: Look, and behold that great and abominable church, which is the mother of abominations, whose founder is the devil. ^verse

---

