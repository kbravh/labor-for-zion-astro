And it came to pass that after I, Nephi, had been carried away in the Spirit, and seen all these things, I returned to the tent of my father. ^verse

---

