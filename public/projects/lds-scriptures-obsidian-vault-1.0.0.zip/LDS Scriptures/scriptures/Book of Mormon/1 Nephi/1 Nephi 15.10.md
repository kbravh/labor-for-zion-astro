Behold, I said unto them: How is it that ye do not keep the commandments of the Lord? How is it that ye will perish, because of the hardness of your hearts? ^verse

---

