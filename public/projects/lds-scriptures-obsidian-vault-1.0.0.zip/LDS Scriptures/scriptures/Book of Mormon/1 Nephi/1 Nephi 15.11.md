Do ye not remember the things which the Lord hath said?—If ye will not harden your hearts, and ask me in faith, believing that ye shall receive, with diligence in keeping my commandments, surely these things shall be made known unto you. ^verse

---

