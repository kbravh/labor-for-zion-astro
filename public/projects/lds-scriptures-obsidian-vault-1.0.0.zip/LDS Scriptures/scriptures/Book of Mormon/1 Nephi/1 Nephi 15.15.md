And then at that day will they not rejoice and give praise unto their everlasting God, their rock and their salvation? Yea, at that day, will they not receive the strength and nourishment from the true vine? Yea, will they not come unto the true fold of God? ^verse

---

