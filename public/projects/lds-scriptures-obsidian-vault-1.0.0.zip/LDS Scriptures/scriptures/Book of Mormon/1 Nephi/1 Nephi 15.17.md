And this is what our father meaneth; and he meaneth that it will not come to pass until after they are scattered by the Gentiles; and he meaneth that it shall come by way of the Gentiles, that the Lord may show his power unto the Gentiles, for the very cause that he shall be rejected of the Jews, or of the house of Israel. ^verse

---

