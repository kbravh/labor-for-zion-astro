Wherefore, our father hath not spoken of our seed alone, but also of all the house of Israel, pointing to the covenant which should be fulfilled in the latter days; which covenant the Lord made to our father Abraham, saying: In thy seed shall all the kindreds of the earth be blessed. ^verse

---

