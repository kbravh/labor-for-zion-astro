And it came to pass that I, Nephi, spake much unto them concerning these things; yea, I spake unto them concerning the restoration of the Jews in the latter days. ^verse

---

