And it came to pass that I beheld my brethren, and they were disputing one with another concerning the things which my father had spoken unto them. ^verse

---

