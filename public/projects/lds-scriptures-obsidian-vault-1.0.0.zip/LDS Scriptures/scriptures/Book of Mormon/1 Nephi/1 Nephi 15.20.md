And I did rehearse unto them the words of Isaiah, who spake concerning the restoration of the Jews, or of the house of Israel; and after they were restored they should no more be confounded, neither should they be scattered again. And it came to pass that I did speak many words unto my brethren, that they were pacified and did humble themselves before the Lord. ^verse

---

