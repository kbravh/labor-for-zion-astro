And it came to pass that they did speak unto me again, saying: What meaneth this thing which our father saw in a dream? What meaneth the tree which he saw? ^verse

---

