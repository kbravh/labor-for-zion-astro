And I said unto them: It was a representation of the tree of life. ^verse

---

