And they said unto me: What meaneth the rod of iron which our father saw, that led to the tree? ^verse

---

