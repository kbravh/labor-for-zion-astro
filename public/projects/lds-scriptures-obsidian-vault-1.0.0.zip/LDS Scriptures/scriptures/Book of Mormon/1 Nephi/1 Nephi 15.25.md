Wherefore, I, Nephi, did exhort them to give heed unto the word of the Lord; yea, I did exhort them with all the energies of my soul, and with all the faculty which I possessed, that they would give heed to the word of God and remember to keep his commandments always in all things. ^verse

---

