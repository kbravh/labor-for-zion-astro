And they said unto me: What meaneth the river of water which our father saw? ^verse

---

