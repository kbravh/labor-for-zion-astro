And I said unto them that the water which my father saw was filthiness; and so much was his mind swallowed up in other things that he beheld not the filthiness of the water. ^verse

---

