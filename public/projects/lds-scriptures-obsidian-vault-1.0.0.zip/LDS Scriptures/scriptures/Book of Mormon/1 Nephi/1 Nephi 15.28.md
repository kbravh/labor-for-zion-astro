And I said unto them that it was an awful gulf, which separated the wicked from the tree of life, and also from the saints of God. ^verse

---

