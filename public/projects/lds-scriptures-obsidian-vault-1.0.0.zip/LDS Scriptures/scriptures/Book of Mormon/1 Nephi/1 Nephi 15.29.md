And I said unto them that it was a representation of that awful hell, which the angel said unto me was prepared for the wicked. ^verse

---

