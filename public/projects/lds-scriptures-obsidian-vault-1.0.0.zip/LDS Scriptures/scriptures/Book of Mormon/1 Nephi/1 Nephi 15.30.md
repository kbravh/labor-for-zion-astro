And I said unto them that our father also saw that the justice of God did also divide the wicked from the righteous; and the brightness thereof was like unto the brightness of a flaming fire, which ascendeth up unto God forever and ever, and hath no end. ^verse

---

