And they said unto me: Doth this thing mean the torment of the body in the days of probation, or doth it mean the final state of the soul after the death of the temporal body, or doth it speak of the things which are temporal? ^verse

---

