And it came to pass that I said unto them that it was a representation of things both temporal and spiritual; for the day should come that they must be judged of their works, yea, even the works which were done by the temporal body in their days of probation. ^verse

---

