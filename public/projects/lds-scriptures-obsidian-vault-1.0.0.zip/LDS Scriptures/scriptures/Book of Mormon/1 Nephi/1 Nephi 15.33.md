Wherefore, if they should die in their wickedness they must be cast off also, as to the things which are spiritual, which are pertaining to righteousness; wherefore, they must be brought to stand before God, to be judged of their works; and if their works have been filthiness they must needs be filthy; and if they be filthy it must needs be that they cannot dwell in the kingdom of God; if so, the kingdom of God must be filthy also. ^verse

---

