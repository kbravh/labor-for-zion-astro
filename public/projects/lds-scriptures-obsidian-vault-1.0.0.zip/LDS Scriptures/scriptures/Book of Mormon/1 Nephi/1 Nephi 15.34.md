But behold, I say unto you, the kingdom of God is not filthy, and there cannot any unclean thing enter into the kingdom of God; wherefore there must needs be a place of filthiness prepared for that which is filthy. ^verse

---

