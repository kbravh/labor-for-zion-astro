And there is a place prepared, yea, even that awful hell of which I have spoken, and the devil is the preparator of it; wherefore the final state of the souls of men is to dwell in the kingdom of God, or to be cast out because of that justice of which I have spoken. ^verse

---

