Wherefore, the wicked are rejected from the righteous, and also from that tree of life, whose fruit is most precious and most desirable above all other fruits; yea, and it is the greatest of all the gifts of God. And thus I spake unto my brethren. Amen. ^verse

---

