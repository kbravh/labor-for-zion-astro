And now I, Nephi, was grieved because of the hardness of their hearts, and also, because of the things which I had seen, and knew they must unavoidably come to pass because of the great wickedness of the children of men. ^verse

---

