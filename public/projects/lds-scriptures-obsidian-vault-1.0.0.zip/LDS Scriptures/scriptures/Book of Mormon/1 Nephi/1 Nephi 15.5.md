And it came to pass that I was overcome because of my afflictions, for I considered that mine afflictions were great above all, because of the destruction of my people, for I had beheld their fall. ^verse

---

