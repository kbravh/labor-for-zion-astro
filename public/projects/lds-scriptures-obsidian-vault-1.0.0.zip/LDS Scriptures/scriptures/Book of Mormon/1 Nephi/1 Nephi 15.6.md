And it came to pass that after I had received strength I spake unto my brethren, desiring to know of them the cause of their disputations. ^verse

---

