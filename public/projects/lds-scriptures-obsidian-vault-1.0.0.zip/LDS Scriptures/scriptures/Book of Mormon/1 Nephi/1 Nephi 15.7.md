And they said: Behold, we cannot understand the words which our father hath spoken concerning the natural branches of the olive tree, and also concerning the Gentiles. ^verse

---

