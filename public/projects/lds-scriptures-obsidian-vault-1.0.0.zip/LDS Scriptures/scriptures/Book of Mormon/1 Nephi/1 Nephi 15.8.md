And I said unto them: Have ye inquired of the Lord? ^verse

---

