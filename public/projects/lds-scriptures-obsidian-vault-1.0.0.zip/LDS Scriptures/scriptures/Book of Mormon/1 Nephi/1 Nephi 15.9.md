And they said unto me: We have not; for the Lord maketh no such thing known unto us. ^verse

---

