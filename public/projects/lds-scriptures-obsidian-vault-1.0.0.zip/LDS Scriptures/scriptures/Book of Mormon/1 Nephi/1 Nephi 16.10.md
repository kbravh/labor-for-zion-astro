And it came to pass that as my father arose in the morning, and went forth to the tent door, to his great astonishment he beheld upon the ground a round ball of curious workmanship; and it was of fine brass. And within the ball were two spindles; and the one pointed the way whither we should go into the wilderness. ^verse

---

