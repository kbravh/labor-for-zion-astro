And it came to pass that we did gather together whatsoever things we should carry into the wilderness, and all the remainder of our provisions which the Lord had given unto us; and we did take seed of every kind that we might carry into the wilderness. ^verse

---

