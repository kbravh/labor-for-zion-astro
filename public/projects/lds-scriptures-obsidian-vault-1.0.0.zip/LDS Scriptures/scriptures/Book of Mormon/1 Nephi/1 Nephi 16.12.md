And it came to pass that we did take our tents and depart into the wilderness, across the river Laman. ^verse

---

