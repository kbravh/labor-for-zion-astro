And it came to pass that we traveled for the space of four days, nearly a south-southeast direction, and we did pitch our tents again; and we did call the name of the place Shazer. ^verse

---

