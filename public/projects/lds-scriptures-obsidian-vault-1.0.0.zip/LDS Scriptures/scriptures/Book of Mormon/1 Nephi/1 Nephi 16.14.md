And it came to pass that we did take our bows and our arrows, and go forth into the wilderness to slay food for our families; and after we had slain food for our families we did return again to our families in the wilderness, to the place of Shazer. And we did go forth again in the wilderness, following the same direction, keeping in the most fertile parts of the wilderness, which were in the borders near the Red Sea. ^verse

---

