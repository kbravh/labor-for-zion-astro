And it came to pass that we did travel for the space of many days, slaying food by the way, with our bows and our arrows and our stones and our slings. ^verse

---

