And we did follow the directions of the ball, which led us in the more fertile parts of the wilderness. ^verse

---

