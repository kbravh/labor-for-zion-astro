And after we had traveled for the space of many days, we did pitch our tents for the space of a time, that we might again rest ourselves and obtain food for our families. ^verse

---

