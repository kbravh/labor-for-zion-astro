And it came to pass that as I, Nephi, went forth to slay food, behold, I did break my bow, which was made of fine steel; and after I did break my bow, behold, my brethren were angry with me because of the loss of my bow, for we did obtain no food. ^verse

---

