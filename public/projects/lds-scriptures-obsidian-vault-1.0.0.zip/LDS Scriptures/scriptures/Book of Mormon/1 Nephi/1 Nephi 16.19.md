And it came to pass that we did return without food to our families, and being much fatigued, because of their journeying, they did suffer much for the want of food. ^verse

---

