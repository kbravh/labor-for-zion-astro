And it came to pass that Laman and Lemuel and the sons of Ishmael did begin to murmur exceedingly, because of their sufferings and afflictions in the wilderness; and also my father began to murmur against the Lord his God; yea, and they were all exceedingly sorrowful, even that they did murmur against the Lord. ^verse

---

