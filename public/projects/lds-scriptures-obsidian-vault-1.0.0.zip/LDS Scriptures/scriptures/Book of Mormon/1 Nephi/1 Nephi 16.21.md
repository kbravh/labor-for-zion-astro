Now it came to pass that I, Nephi, having been afflicted with my brethren because of the loss of my bow, and their bows having lost their springs, it began to be exceedingly difficult, yea, insomuch that we could obtain no food. ^verse

---

