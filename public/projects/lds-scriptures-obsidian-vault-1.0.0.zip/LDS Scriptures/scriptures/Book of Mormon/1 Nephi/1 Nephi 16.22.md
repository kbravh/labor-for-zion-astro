And it came to pass that I, Nephi, did speak much unto my brethren, because they had hardened their hearts again, even unto complaining against the Lord their God. ^verse

---

