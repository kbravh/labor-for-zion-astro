And it came to pass that I, Nephi, did make out of wood a bow, and out of a straight stick, an arrow; wherefore, I did arm myself with a bow and an arrow, with a sling and with stones. And I said unto my father: Whither shall I go to obtain food? ^verse

---

