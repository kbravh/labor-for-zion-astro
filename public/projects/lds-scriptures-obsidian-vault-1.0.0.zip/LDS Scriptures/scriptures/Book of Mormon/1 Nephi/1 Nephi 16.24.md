And it came to pass that he did inquire of the Lord, for they had humbled themselves because of my words; for I did say many things unto them in the energy of my soul. ^verse

---

