And it came to pass that the voice of the Lord came unto my father; and he was truly chastened because of his murmuring against the Lord, insomuch that he was brought down into the depths of sorrow. ^verse

---

