And it came to pass that the voice of the Lord said unto him: Look upon the ball, and behold the things which are written. ^verse

---

