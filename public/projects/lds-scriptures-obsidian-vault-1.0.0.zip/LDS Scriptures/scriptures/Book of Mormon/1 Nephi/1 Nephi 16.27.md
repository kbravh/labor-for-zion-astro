And it came to pass that when my father beheld the things which were written upon the ball, he did fear and tremble exceedingly, and also my brethren and the sons of Ishmael and our wives. ^verse

---

