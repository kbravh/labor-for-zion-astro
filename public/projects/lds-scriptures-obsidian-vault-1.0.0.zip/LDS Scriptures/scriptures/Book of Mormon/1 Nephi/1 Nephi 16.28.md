And it came to pass that I, Nephi, beheld the pointers which were in the ball, that they did work according to the faith and diligence and heed which we did give unto them. ^verse

---

