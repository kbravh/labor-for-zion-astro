And it came to pass that I, Nephi, did go forth up into the top of the mountain, according to the directions which were given upon the ball. ^verse

---

