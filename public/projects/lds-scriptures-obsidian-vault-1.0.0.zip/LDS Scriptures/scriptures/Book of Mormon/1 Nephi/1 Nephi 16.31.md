And it came to pass that I did slay wild beasts, insomuch that I did obtain food for our families. ^verse

---

