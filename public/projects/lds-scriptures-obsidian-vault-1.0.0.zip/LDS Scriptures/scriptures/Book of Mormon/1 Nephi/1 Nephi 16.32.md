And it came to pass that I did return to our tents, bearing the beasts which I had slain; and now when they beheld that I had obtained food, how great was their joy! And it came to pass that they did humble themselves before the Lord, and did give thanks unto him. ^verse

---

