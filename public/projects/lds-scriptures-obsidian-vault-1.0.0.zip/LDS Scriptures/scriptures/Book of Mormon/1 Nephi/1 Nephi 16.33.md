And it came to pass that we did again take our journey, traveling nearly the same course as in the beginning; and after we had traveled for the space of many days we did pitch our tents again, that we might tarry for the space of a time. ^verse

---

