And it came to pass that Ishmael died, and was buried in the place which was called Nahom. ^verse

---

