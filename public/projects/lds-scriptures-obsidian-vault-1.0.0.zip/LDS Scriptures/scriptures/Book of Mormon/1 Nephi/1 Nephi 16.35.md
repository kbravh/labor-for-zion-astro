And it came to pass that the daughters of Ishmael did mourn exceedingly, because of the loss of their father, and because of their afflictions in the wilderness; and they did murmur against my father, because he had brought them out of the land of Jerusalem, saying: Our father is dead; yea, and we have wandered much in the wilderness, and we have suffered much affliction, hunger, thirst, and fatigue; and after all these sufferings we must perish in the wilderness with hunger. ^verse

---

