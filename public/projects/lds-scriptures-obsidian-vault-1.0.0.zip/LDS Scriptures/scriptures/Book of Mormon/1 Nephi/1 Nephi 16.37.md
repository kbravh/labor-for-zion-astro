And Laman said unto Lemuel and also unto the sons of Ishmael: Behold, let us slay our father, and also our brother Nephi, who has taken it upon him to be our ruler and our teacher, who are his elder brethren. ^verse

---

