Now, he says that the Lord has talked with him, and also that angels have ministered unto him. But behold, we know that he lies unto us; and he tells us these things, and he worketh many things by his cunning arts, that he may deceive our eyes, thinking, perhaps, that he may lead us away into some strange wilderness; and after he has led us away, he has thought to make himself a king and a ruler over us, that he may do with us according to his will and pleasure. And after this manner did my brother Laman stir up their hearts to anger. ^verse

---

