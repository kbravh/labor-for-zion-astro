And it came to pass that the Lord was with us, yea, even the voice of the Lord came and did speak many words unto them, and did chasten them exceedingly; and after they were chastened by the voice of the Lord they did turn away their anger, and did repent of their sins, insomuch that the Lord did bless us again with food, that we did not perish. ^verse

---

