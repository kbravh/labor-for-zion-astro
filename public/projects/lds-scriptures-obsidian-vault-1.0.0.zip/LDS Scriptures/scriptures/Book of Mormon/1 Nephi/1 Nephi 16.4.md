And it came to pass that I, Nephi, did exhort my brethren, with all diligence, to keep the commandments of the Lord. ^verse

---

