And it came to pass that they did humble themselves before the Lord; insomuch that I had joy and great hopes of them, that they would walk in the paths of righteousness. ^verse

---

