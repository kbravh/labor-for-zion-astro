Now, all these things were said and done as my father dwelt in a tent in the valley which he called Lemuel. ^verse

---

