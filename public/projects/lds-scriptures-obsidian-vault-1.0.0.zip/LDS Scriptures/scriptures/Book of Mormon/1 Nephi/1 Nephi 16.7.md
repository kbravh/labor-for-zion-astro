And it came to pass that I, Nephi, took one of the daughters of Ishmael to wife; and also, my brethren took of the daughters of Ishmael to wife; and also Zoram took the eldest daughter of Ishmael to wife. ^verse

---

