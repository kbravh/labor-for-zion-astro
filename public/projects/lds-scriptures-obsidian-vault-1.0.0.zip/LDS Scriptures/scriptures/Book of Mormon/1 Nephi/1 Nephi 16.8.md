And thus my father had fulfilled all the commandments of the Lord which had been given unto him. And also, I, Nephi, had been blessed of the Lord exceedingly. ^verse

---

