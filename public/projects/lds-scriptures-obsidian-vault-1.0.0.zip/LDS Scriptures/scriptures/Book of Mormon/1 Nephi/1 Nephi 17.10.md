And it came to pass that the Lord told me whither I should go to find ore, that I might make tools. ^verse

---

