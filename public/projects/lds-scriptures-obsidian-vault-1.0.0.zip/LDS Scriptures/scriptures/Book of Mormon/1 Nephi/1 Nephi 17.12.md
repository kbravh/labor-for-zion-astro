For the Lord had not hitherto suffered that we should make much fire, as we journeyed in the wilderness; for he said: I will make thy food become sweet, that ye cook it not; ^verse

---

