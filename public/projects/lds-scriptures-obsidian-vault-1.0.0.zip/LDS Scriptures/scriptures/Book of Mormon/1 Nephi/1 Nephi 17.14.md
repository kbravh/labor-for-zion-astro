Yea, and the Lord said also that: After ye have arrived in the promised land, ye shall know that I, the Lord, am God; and that I, the Lord, did deliver you from destruction; yea, that I did bring you out of the land of Jerusalem. ^verse

---

