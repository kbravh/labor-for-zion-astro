Wherefore, I, Nephi, did strive to keep the commandments of the Lord, and I did exhort my brethren to faithfulness and diligence. ^verse

---

