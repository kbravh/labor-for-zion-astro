And it came to pass that I did make tools of the ore which I did molten out of the rock. ^verse

---

