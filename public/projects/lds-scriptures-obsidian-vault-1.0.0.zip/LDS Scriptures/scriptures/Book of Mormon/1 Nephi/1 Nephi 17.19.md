And now it came to pass that I, Nephi, was exceedingly sorrowful because of the hardness of their hearts; and now when they saw that I began to be sorrowful they were glad in their hearts, insomuch that they did rejoice over me, saying: We knew that ye could not construct a ship, for we knew that ye were lacking in judgment; wherefore, thou canst not accomplish so great a work. ^verse

---

