And it came to pass that I, Nephi, spake unto them, saying: Do ye believe that our fathers, who were the children of Israel, would have been led away out of the hands of the Egyptians if they had not hearkened unto the words of the Lord? ^verse

---

