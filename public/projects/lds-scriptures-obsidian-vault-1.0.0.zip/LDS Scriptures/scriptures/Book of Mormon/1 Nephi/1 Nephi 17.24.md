Yea, do ye suppose that they would have been led out of bondage, if the Lord had not commanded Moses that he should lead them out of bondage? ^verse

---

