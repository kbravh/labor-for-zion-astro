Now ye know that the children of Israel were in bondage; and ye know that they were laden with tasks, which were grievous to be borne; wherefore, ye know that it must needs be a good thing for them, that they should be brought out of bondage. ^verse

---

