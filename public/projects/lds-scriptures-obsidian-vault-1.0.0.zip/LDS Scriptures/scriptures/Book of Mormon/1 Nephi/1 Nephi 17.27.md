But ye know that the Egyptians were drowned in the Red Sea, who were the armies of Pharaoh. ^verse

---

