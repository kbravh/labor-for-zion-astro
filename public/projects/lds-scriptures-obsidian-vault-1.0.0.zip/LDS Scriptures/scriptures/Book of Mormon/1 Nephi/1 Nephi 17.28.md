And ye also know that they were fed with manna in the wilderness. ^verse

---

