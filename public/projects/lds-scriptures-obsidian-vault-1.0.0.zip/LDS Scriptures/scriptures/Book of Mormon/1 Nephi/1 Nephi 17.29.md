Yea, and ye also know that Moses, by his word according to the power of God which was in him, smote the rock, and there came forth water, that the children of Israel might quench their thirst. ^verse

---

