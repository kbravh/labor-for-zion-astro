And it came to pass that according to his word he did destroy them; and according to his word he did lead them; and according to his word he did do all things for them; and there was not any thing done save it were by his word. ^verse

---

