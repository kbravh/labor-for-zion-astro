And after they had crossed the river Jordan he did make them mighty unto the driving out of the children of the land, yea, unto the scattering them to destruction. ^verse

---

