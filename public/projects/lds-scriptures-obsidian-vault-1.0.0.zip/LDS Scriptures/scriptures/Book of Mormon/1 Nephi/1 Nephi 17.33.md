And now, do ye suppose that the children of this land, who were in the land of promise, who were driven out by our fathers, do ye suppose that they were righteous? Behold, I say unto you, Nay. ^verse

---

