Do ye suppose that our fathers would have been more choice than they if they had been righteous? I say unto you, Nay. ^verse

---

