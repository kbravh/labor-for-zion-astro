Behold, the Lord esteemeth all flesh in one; he that is righteous is favored of God. But behold, this people had rejected every word of God, and they were ripe in iniquity; and the fulness of the wrath of God was upon them; and the Lord did curse the land against them, and bless it unto our fathers; yea, he did curse it against them unto their destruction, and he did bless it unto our fathers unto their obtaining power over it. ^verse

---

