Behold, the Lord hath created the earth that it should be inhabited; and he hath created his children that they should possess it. ^verse

---

