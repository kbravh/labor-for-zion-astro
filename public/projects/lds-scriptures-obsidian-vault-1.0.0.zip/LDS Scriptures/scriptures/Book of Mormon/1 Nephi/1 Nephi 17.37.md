And he raiseth up a righteous nation, and destroyeth the nations of the wicked. ^verse

---

