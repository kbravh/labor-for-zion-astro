And he leadeth away the righteous into precious lands, and the wicked he destroyeth, and curseth the land unto them for their sakes. ^verse

---

