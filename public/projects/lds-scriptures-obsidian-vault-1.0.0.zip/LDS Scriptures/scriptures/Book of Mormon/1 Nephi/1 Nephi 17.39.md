He ruleth high in the heavens, for it is his throne, and this earth is his footstool. ^verse

---

