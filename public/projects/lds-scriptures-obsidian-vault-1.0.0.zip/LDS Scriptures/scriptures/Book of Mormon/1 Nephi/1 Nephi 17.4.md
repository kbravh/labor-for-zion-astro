And we did sojourn for the space of many years, yea, even eight years in the wilderness. ^verse

---

