And he did straiten them in the wilderness with his rod; for they hardened their hearts, even as ye have; and the Lord straitened them because of their iniquity. He sent fiery flying serpents among them; and after they were bitten he prepared a way that they might be healed; and the labor which they had to perform was to look; and because of the simpleness of the way, or the easiness of it, there were many who perished. ^verse

---

