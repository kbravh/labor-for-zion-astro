And they did harden their hearts from time to time, and they did revile against Moses, and also against God; nevertheless, ye know that they were led forth by his matchless power into the land of promise. ^verse

---

