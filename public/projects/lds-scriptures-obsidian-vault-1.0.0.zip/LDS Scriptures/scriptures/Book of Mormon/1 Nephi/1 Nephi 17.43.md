And now, after all these things, the time has come that they have become wicked, yea, nearly unto ripeness; and I know not but they are at this day about to be destroyed; for I know that the day must surely come that they must be destroyed, save a few only, who shall be led away into captivity. ^verse

---

