Wherefore, the Lord commanded my father that he should depart into the wilderness; and the Jews also sought to take away his life; yea, and ye also have sought to take away his life; wherefore, ye are murderers in your hearts and ye are like unto them. ^verse

---

