And ye also know that by the power of his almighty word he can cause the earth that it shall pass away; yea, and ye know that by his word he can cause the rough places to be made smooth, and smooth places shall be broken up. O, then, why is it, that ye can be so hard in your hearts? ^verse

---

