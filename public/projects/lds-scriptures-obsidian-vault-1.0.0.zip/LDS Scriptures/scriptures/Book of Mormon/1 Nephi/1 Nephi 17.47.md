Behold, my soul is rent with anguish because of you, and my heart is pained; I fear lest ye shall be cast off forever. Behold, I am full of the Spirit of God, insomuch that my frame has no strength. ^verse

---

