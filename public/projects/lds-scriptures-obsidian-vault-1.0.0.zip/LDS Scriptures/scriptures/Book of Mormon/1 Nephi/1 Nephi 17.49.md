And it came to pass that I, Nephi, said unto them that they should murmur no more against their father; neither should they withhold their labor from me, for God had commanded me that I should build a ship. ^verse

---

