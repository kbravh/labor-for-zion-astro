And we did come to the land which we called Bountiful, because of its much fruit and also wild honey; and all these things were prepared of the Lord that we might not perish. And we beheld the sea, which we called Irreantum, which, being interpreted, is many waters. ^verse

---

