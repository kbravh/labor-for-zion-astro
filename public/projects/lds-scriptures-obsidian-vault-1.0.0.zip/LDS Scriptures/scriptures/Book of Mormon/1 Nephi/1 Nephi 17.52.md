And it came to pass that I, Nephi, said many things unto my brethren, insomuch that they were confounded and could not contend against me; neither durst they lay their hands upon me nor touch me with their fingers, even for the space of many days. Now they durst not do this lest they should wither before me, so powerful was the Spirit of God; and thus it had wrought upon them. ^verse

---

