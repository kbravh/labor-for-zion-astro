And it came to pass that the Lord said unto me: Stretch forth thine hand again unto thy brethren, and they shall not wither before thee, but I will shock them, saith the Lord, and this will I do, that they may know that I am the Lord their God. ^verse

---

