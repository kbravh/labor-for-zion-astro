And it came to pass that I stretched forth my hand unto my brethren, and they did not wither before me; but the Lord did shake them, even according to the word which he had spoken. ^verse

---

