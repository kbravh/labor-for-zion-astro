And now, they said: We know of a surety that the Lord is with thee, for we know that it is the power of the Lord that has shaken us. And they fell down before me, and were about to worship me, but I would not suffer them, saying: I am thy brother, yea, even thy younger brother; wherefore, worship the Lord thy God, and honor thy father and thy mother, that thy days may be long in the land which the Lord thy God shall give thee. ^verse

---

