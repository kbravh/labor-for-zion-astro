And it came to pass that we did pitch our tents by the seashore; and notwithstanding we had suffered many afflictions and much difficulty, yea, even so much that we cannot write them all, we were exceedingly rejoiced when we came to the seashore; and we called the place Bountiful, because of its much fruit. ^verse

---

