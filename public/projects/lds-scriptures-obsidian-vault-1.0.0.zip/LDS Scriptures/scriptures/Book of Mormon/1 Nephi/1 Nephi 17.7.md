And it came to pass that after I, Nephi, had been in the land of Bountiful for the space of many days, the voice of the Lord came unto me, saying: Arise, and get thee into the mountain. And it came to pass that I arose and went up into the mountain, and cried unto the Lord. ^verse

---

