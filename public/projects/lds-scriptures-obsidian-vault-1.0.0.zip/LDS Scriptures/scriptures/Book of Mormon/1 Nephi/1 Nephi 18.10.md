And I, Nephi, began to fear exceedingly lest the Lord should be angry with us, and smite us because of our iniquity, that we should be swallowed up in the depths of the sea; wherefore, I, Nephi, began to speak to them with much soberness; but behold they were angry with me, saying: We will not that our younger brother shall be a ruler over us. ^verse

---

