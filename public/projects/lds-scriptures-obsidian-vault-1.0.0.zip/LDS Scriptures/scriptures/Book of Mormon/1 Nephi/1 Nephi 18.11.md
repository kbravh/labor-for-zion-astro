And it came to pass that Laman and Lemuel did take me and bind me with cords, and they did treat me with much harshness; nevertheless, the Lord did suffer it that he might show forth his power, unto the fulfilling of his word which he had spoken concerning the wicked. ^verse

---

