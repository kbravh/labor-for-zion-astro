And it came to pass that after they had bound me insomuch that I could not move, the compass, which had been prepared of the Lord, did cease to work. ^verse

---

