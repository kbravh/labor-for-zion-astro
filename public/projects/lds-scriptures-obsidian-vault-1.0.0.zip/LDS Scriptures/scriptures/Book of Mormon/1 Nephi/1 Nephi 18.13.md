Wherefore, they knew not whither they should steer the ship, insomuch that there arose a great storm, yea, a great and terrible tempest, and we were driven back upon the waters for the space of three days; and they began to be frightened exceedingly lest they should be drowned in the sea; nevertheless they did not loose me. ^verse

---

