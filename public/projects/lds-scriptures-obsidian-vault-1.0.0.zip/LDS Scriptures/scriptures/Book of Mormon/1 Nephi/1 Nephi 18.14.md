And on the fourth day, which we had been driven back, the tempest began to be exceedingly sore. ^verse

---

