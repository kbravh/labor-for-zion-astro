Because of their grief and much sorrow, and the iniquity of my brethren, they were brought near even to be carried out of this time to meet their God; yea, their grey hairs were about to be brought down to lie low in the dust; yea, even they were near to be cast with sorrow into a watery grave. ^verse

---

