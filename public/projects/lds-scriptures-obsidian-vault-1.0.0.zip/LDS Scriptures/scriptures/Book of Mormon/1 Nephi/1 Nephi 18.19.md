And Jacob and Joseph also, being young, having need of much nourishment, were grieved because of the afflictions of their mother; and also my wife with her tears and prayers, and also my children, did not soften the hearts of my brethren that they would loose me. ^verse

---

