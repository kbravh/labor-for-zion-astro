And there was nothing save it were the power of God, which threatened them with destruction, could soften their hearts; wherefore, when they saw that they were about to be swallowed up in the depths of the sea they repented of the thing which they had done, insomuch that they loosed me. ^verse

---

