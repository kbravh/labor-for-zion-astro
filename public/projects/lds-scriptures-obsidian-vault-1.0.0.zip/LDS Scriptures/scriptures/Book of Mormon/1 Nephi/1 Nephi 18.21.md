And it came to pass after they had loosed me, behold, I took the compass, and it did work whither I desired it. And it came to pass that I prayed unto the Lord; and after I had prayed the winds did cease, and the storm did cease, and there was a great calm. ^verse

---

