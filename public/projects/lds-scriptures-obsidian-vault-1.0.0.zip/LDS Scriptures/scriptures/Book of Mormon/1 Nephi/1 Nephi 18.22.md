And it came to pass that I, Nephi, did guide the ship, that we sailed again towards the promised land. ^verse

---

