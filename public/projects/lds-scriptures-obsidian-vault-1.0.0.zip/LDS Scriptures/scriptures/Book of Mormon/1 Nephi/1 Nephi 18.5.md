And it came to pass that the voice of the Lord came unto my father, that we should arise and go down into the ship. ^verse

---

