And it came to pass that on the morrow, after we had prepared all things, much fruits and meat from the wilderness, and honey in abundance, and provisions according to that which the Lord had commanded us, we did go down into the ship, with all our loading and our seeds, and whatsoever thing we had brought with us, every one according to his age; wherefore, we did all go down into the ship, with our wives and our children. ^verse

---

