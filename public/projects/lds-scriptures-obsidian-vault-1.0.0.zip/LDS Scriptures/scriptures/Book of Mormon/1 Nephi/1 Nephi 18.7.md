And now, my father had begat two sons in the wilderness; the elder was called Jacob and the younger Joseph. ^verse

---

