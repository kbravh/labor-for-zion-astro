And as for those who are at Jerusalem, saith the prophet, they shall be scourged by all people, because they crucify the God of Israel, and turn their hearts aside, rejecting signs and wonders, and the power and glory of the God of Israel. ^verse

---

