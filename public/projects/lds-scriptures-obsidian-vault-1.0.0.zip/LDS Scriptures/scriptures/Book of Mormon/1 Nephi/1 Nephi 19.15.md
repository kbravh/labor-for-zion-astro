Nevertheless, when that day cometh, saith the prophet, that they no more turn aside their hearts against the Holy One of Israel, then will he remember the covenants which he made to their fathers. ^verse

---

