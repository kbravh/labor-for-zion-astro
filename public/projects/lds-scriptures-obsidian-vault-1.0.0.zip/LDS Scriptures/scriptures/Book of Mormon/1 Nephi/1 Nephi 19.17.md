Yea, and all the earth shall see the salvation of the Lord, saith the prophet; every nation, kindred, tongue and people shall be blessed. ^verse

---

