And I, Nephi, have written these things unto my people, that perhaps I might persuade them that they would remember the Lord their Redeemer. ^verse

---

