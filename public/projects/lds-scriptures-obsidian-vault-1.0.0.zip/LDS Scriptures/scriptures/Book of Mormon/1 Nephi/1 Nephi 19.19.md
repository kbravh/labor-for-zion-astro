Wherefore, I speak unto all the house of Israel, if it so be that they should obtain these things. ^verse

---

