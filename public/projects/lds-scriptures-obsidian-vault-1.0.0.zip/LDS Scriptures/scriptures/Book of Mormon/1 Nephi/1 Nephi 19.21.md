And he surely did show unto the prophets of old all things concerning them; and also he did show unto many concerning us; wherefore, it must needs be that we know concerning them for they are written upon the plates of brass. ^verse

---

