And an account of my making these plates shall be given hereafter; and then, behold, I proceed according to that which I have spoken; and this I do that the more sacred things may be kept for the knowledge of my people. ^verse

---

