Nevertheless, I do not write anything upon plates save it be that I think it be sacred. And now, if I do err, even did they err of old; not that I would excuse myself because of other men, but because of the weakness which is in me, according to the flesh, I would excuse myself. ^verse

---

