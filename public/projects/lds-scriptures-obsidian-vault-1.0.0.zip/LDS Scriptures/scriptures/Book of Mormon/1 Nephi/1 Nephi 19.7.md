For the things which some men esteem to be of great worth, both to the body and soul, others set at naught and trample under their feet. Yea, even the very God of Israel do men trample under their feet; I say, trample under their feet but I would speak in other words—they set him at naught, and hearken not to the voice of his counsels. ^verse

---

