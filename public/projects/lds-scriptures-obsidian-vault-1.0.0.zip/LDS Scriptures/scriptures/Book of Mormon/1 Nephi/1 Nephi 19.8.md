And behold he cometh, according to the words of the angel, in six hundred years from the time my father left Jerusalem. ^verse

---

