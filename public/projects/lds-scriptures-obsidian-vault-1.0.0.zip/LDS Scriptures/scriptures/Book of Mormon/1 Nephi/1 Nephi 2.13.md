Neither did they believe that Jerusalem, that great city, could be destroyed according to the words of the prophets. And they were like unto the Jews who were at Jerusalem, who sought to take away the life of my father. ^verse

---

