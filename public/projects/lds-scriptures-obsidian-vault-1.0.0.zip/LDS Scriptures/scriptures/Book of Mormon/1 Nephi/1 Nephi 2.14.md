And it came to pass that my father did speak unto them in the valley of Lemuel, with power, being filled with the Spirit, until their frames did shake before him. And he did confound them, that they durst not utter against him; wherefore, they did as he commanded them. ^verse

---

