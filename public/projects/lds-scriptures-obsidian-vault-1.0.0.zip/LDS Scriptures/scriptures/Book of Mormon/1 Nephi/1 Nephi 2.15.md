And my father dwelt in a tent. ^verse

---

