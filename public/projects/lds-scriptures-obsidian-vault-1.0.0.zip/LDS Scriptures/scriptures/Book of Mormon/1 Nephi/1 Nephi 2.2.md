And it came to pass that the Lord commanded my father, even in a dream, that he should take his family and depart into the wilderness. ^verse

---

