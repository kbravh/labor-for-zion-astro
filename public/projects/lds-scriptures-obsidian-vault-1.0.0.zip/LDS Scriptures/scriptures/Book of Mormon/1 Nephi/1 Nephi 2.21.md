And inasmuch as thy brethren shall rebel against thee, they shall be cut off from the presence of the Lord. ^verse

---

