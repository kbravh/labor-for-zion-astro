And inasmuch as thou shalt keep my commandments, thou shalt be made a ruler and a teacher over thy brethren. ^verse

---

