And if it so be that they rebel against me, they shall be a scourge unto thy seed, to stir them up in the ways of remembrance. ^verse

---

