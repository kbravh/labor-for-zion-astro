And it came to pass that he was obedient unto the word of the Lord, wherefore he did as the Lord commanded him. ^verse

---

