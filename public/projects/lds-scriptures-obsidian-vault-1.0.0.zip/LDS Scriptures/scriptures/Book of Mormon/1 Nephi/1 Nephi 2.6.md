And it came to pass that when he had traveled three days in the wilderness, he pitched his tent in a valley by the side of a river of water. ^verse

---

