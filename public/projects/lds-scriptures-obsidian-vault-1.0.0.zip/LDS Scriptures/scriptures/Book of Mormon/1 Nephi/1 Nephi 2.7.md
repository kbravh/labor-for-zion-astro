And it came to pass that he built an altar of stones, and made an offering unto the Lord, and gave thanks unto the Lord our God. ^verse

---

