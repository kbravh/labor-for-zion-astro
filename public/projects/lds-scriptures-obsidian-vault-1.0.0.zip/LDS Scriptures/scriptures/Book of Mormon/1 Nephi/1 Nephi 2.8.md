And it came to pass that he called the name of the river, Laman, and it emptied into the Red Sea; and the valley was in the borders near the mouth thereof. ^verse

---

