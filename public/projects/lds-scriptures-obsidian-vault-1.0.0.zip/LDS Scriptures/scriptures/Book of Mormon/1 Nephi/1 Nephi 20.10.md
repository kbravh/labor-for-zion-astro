For, behold, I have refined thee, I have chosen thee in the furnace of affliction. ^verse

---

