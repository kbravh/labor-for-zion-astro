For mine own sake, yea, for mine own sake will I do this, for I will not suffer my name to be polluted, and I will not give my glory unto another. ^verse

---

