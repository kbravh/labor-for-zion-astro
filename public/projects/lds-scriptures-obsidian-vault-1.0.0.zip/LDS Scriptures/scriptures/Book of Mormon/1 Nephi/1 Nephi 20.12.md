Hearken unto me, O Jacob, and Israel my called, for I am he; I am the first, and I am also the last. ^verse

---

