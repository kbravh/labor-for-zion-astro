Mine hand hath also laid the foundation of the earth, and my right hand hath spanned the heavens. I call unto them and they stand up together. ^verse

---

