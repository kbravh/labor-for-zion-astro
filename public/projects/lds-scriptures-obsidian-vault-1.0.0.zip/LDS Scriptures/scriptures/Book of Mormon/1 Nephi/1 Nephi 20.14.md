All ye, assemble yourselves, and hear; who among them hath declared these things unto them? The Lord hath loved him; yea, and he will fulfil his word which he hath declared by them; and he will do his pleasure on Babylon, and his arm shall come upon the Chaldeans. ^verse

---

