Also, saith the Lord; I the Lord, yea, I have spoken; yea, I have called him to declare, I have brought him, and he shall make his way prosperous. ^verse

---

