Come ye near unto me; I have not spoken in secret; from the beginning, from the time that it was declared have I spoken; and the Lord God, and his Spirit, hath sent me. ^verse

---

