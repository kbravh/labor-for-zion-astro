And thus saith the Lord, thy Redeemer, the Holy One of Israel; I have sent him, the Lord thy God who teacheth thee to profit, who leadeth thee by the way thou shouldst go, hath done it. ^verse

---

