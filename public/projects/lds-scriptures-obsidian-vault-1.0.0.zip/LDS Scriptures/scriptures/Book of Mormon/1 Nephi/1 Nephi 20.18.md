O that thou hadst hearkened to my commandments—then had thy peace been as a river, and thy righteousness as the waves of the sea. ^verse

---

