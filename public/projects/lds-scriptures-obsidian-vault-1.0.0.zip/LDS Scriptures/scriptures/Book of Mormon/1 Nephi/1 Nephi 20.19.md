Thy seed also had been as the sand; the offspring of thy bowels like the gravel thereof; his name should not have been cut off nor destroyed from before me. ^verse

---

