Go ye forth of Babylon, flee ye from the Chaldeans, with a voice of singing declare ye, tell this, utter to the end of the earth; say ye: The Lord hath redeemed his servant Jacob. ^verse

---

