And they thirsted not; he led them through the deserts; he caused the waters to flow out of the rock for them; he clave the rock also and the waters gushed out. ^verse

---

