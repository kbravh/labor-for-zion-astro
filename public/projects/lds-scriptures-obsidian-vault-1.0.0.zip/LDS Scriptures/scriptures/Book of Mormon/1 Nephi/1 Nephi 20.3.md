Behold, I have declared the former things from the beginning; and they went forth out of my mouth, and I showed them. I did show them suddenly. ^verse

---

