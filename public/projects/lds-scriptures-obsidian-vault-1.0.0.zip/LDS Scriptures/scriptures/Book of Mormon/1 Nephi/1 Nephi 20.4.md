And I did it because I knew that thou art obstinate, and thy neck is an iron sinew, and thy brow brass; ^verse

---

