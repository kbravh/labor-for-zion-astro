And I have even from the beginning declared to thee; before it came to pass I showed them thee; and I showed them for fear lest thou shouldst say—Mine idol hath done them, and my graven image, and my molten image hath commanded them. ^verse

---

