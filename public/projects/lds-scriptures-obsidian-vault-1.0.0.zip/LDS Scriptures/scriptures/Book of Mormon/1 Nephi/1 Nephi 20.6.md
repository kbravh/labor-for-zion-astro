Thou hast seen and heard all this; and will ye not declare them? And that I have showed thee new things from this time, even hidden things, and thou didst not know them. ^verse

---

