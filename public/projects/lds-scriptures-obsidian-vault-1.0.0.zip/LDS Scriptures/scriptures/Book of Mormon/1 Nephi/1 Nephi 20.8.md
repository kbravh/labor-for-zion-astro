Yea, and thou heardest not; yea, thou knewest not; yea, from that time thine ear was not opened; for I knew that thou wouldst deal very treacherously, and wast called a transgressor from the womb. ^verse

---

