Nevertheless, for my name’s sake will I defer mine anger, and for my praise will I refrain from thee, that I cut thee not off. ^verse

---

