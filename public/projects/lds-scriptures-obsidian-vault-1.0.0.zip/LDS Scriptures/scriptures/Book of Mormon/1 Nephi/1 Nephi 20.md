
[[1 Nephi 19|Previous chapter]]

The Lord reveals His purposes to Israel—Israel has been chosen in the furnace of affliction and is to go forth from Babylon—Compare Isaiah 48. About 588–570 B.C.

###### 1 ![[1 Nephi 20.1#^verse]]
###### 2 ![[1 Nephi 20.2#^verse]]
###### 3 ![[1 Nephi 20.3#^verse]]
###### 4 ![[1 Nephi 20.4#^verse]]
###### 5 ![[1 Nephi 20.5#^verse]]
###### 6 ![[1 Nephi 20.6#^verse]]
###### 7 ![[1 Nephi 20.7#^verse]]
###### 8 ![[1 Nephi 20.8#^verse]]
###### 9 ![[1 Nephi 20.9#^verse]]
###### 10 ![[1 Nephi 20.10#^verse]]
###### 11 ![[1 Nephi 20.11#^verse]]
###### 12 ![[1 Nephi 20.12#^verse]]
###### 13 ![[1 Nephi 20.13#^verse]]
###### 14 ![[1 Nephi 20.14#^verse]]
###### 15 ![[1 Nephi 20.15#^verse]]
###### 16 ![[1 Nephi 20.16#^verse]]
###### 17 ![[1 Nephi 20.17#^verse]]
###### 18 ![[1 Nephi 20.18#^verse]]
###### 19 ![[1 Nephi 20.19#^verse]]
###### 20 ![[1 Nephi 20.20#^verse]]
###### 21 ![[1 Nephi 20.21#^verse]]
###### 22 ![[1 Nephi 20.22#^verse]]

[[1 Nephi 21|Next chapter]]