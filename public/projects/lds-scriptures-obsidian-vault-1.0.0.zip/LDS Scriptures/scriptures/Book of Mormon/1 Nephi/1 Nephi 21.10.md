They shall not hunger nor thirst, neither shall the heat nor the sun smite them; for he that hath mercy on them shall lead them, even by the springs of water shall he guide them. ^verse

---

