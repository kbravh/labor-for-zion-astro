And I will make all my mountains a way, and my highways shall be exalted. ^verse

---

