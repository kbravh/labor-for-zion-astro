And then, O house of Israel, behold, these shall come from far; and lo, these from the north and from the west; and these from the land of Sinim. ^verse

---

