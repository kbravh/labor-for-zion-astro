But, behold, Zion hath said: The Lord hath forsaken me, and my Lord hath forgotten me—but he will show that he hath not. ^verse

---

