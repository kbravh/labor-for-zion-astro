Behold, I have graven thee upon the palms of my hands; thy walls are continually before me. ^verse

---

