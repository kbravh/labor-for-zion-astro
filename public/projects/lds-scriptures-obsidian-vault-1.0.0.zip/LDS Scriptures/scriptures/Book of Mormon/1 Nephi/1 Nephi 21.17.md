Thy children shall make haste against thy destroyers; and they that made thee waste shall go forth of thee. ^verse

---

