For thy waste and thy desolate places, and the land of thy destruction, shall even now be too narrow by reason of the inhabitants; and they that swallowed thee up shall be far away. ^verse

---

