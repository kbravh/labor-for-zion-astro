The children whom thou shalt have, after thou hast lost the first, shall again in thine ears say: The place is too strait for me; give place to me that I may dwell. ^verse

---

