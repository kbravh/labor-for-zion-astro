Then shalt thou say in thine heart: Who hath begotten me these, seeing I have lost my children, and am desolate, a captive, and removing to and fro? And who hath brought up these? Behold, I was left alone; these, where have they been? ^verse

---

