And kings shall be thy nursing fathers, and their queens thy nursing mothers; they shall bow down to thee with their face towards the earth, and lick up the dust of thy feet; and thou shalt know that I am the Lord; for they shall not be ashamed that wait for me. ^verse

---

