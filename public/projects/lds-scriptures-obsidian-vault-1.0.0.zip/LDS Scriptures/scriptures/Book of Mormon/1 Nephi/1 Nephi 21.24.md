For shall the prey be taken from the mighty, or the lawful captives delivered? ^verse

---

