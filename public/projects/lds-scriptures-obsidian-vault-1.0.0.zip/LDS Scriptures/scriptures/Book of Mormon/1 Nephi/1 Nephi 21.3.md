And said unto me: Thou art my servant, O Israel, in whom I will be glorified. ^verse

---

