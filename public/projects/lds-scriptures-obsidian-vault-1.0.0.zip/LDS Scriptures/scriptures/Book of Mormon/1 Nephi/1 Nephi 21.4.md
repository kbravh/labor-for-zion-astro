Then I said, I have labored in vain, I have spent my strength for naught and in vain; surely my judgment is with the Lord, and my work with my God. ^verse

---

