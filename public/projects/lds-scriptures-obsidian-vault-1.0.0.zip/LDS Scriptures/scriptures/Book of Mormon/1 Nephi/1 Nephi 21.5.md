And now, saith the Lord—that formed me from the womb that I should be his servant, to bring Jacob again to him—though Israel be not gathered, yet shall I be glorious in the eyes of the Lord, and my God shall be my strength. ^verse

---

