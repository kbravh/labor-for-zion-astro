And he said: It is a light thing that thou shouldst be my servant to raise up the tribes of Jacob, and to restore the preserved of Israel. I will also give thee for a light to the Gentiles, that thou mayest be my salvation unto the ends of the earth. ^verse

---

