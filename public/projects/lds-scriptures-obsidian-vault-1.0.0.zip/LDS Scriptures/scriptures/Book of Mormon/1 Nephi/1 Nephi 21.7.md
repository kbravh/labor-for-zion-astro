Thus saith the Lord, the Redeemer of Israel, his Holy One, to him whom man despiseth, to him whom the nations abhorreth, to servant of rulers: Kings shall see and arise, princes also shall worship, because of the Lord that is faithful. ^verse

---

