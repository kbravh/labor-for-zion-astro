Thus saith the Lord: In an acceptable time have I heard thee, O isles of the sea, and in a day of salvation have I helped thee; and I will preserve thee, and give thee my servant for a covenant of the people, to establish the earth, to cause to inherit the desolate heritages; ^verse

---

