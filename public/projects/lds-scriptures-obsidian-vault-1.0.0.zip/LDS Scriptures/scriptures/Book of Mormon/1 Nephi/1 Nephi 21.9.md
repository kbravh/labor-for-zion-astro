That thou mayest say to the prisoners: Go forth; to them that sit in darkness: Show yourselves. They shall feed in the ways, and their pastures shall be in all high places. ^verse

---

