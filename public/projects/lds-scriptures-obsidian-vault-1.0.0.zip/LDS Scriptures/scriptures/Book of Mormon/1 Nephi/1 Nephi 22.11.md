Wherefore, the Lord God will proceed to make bare his arm in the eyes of all the nations, in bringing about his covenants and his gospel unto those who are of the house of Israel. ^verse

---

