For behold, the righteous shall not perish; for the time surely must come that all they who fight against Zion shall be cut off. ^verse

---

