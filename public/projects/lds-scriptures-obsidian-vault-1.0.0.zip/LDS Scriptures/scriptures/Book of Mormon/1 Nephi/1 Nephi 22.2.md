And I, Nephi, said unto them: Behold they were manifest unto the prophet by the voice of the Spirit; for by the Spirit are all things made known unto the prophets, which shall come upon the children of men according to the flesh. ^verse

---

