And now behold, I, Nephi, say unto you that all these things must come according to the flesh. ^verse

---

