And now I, Nephi, make an end; for I durst not speak further as yet concerning these things. ^verse

---

