Wherefore, the things of which I have read are things pertaining to things both temporal and spiritual; for it appears that the house of Israel, sooner or later, will be scattered upon all the face of the earth, and also among all nations. ^verse

---

