Wherefore, my brethren, I would that ye should consider that the things which have been written upon the plates of brass are true; and they testify that a man must be obedient to the commandments of God. ^verse

---

