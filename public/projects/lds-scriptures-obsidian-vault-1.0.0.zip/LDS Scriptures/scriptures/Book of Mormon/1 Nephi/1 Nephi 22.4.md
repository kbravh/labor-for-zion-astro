And behold, there are many who are already lost from the knowledge of those who are at Jerusalem. Yea, the more part of all the tribes have been led away; and they are scattered to and fro upon the isles of the sea; and whither they are none of us knoweth, save that we know that they have been led away. ^verse

---

