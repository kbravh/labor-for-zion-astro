Nevertheless, after they shall be nursed by the Gentiles, and the Lord has lifted up his hand upon the Gentiles and set them up for a standard, and their children have been carried in their arms, and their daughters have been carried upon their shoulders, behold these things of which are spoken are temporal; for thus are the covenants of the Lord with our fathers; and it meaneth us in the days to come, and also all our brethren who are of the house of Israel. ^verse

---

