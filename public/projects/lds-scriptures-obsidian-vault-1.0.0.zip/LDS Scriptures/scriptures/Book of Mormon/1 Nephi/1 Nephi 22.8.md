And after our seed is scattered the Lord God will proceed to do a marvelous work among the Gentiles, which shall be of great worth unto our seed; wherefore, it is likened unto their being nourished by the Gentiles and being carried in their arms and upon their shoulders. ^verse

---

