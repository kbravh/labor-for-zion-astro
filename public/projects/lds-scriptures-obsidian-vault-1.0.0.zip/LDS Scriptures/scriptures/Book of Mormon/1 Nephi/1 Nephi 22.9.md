And it shall also be of worth unto the Gentiles; and not only unto the Gentiles but unto all the house of Israel, unto the making known of the covenants of the Father of heaven unto Abraham, saying: In thy seed shall all the kindreds of the earth be blessed. ^verse

---

