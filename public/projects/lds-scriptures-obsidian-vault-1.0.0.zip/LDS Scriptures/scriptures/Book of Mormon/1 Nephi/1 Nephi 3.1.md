And it came to pass that I, Nephi, returned from speaking with the Lord, to the tent of my father. ^verse

---

