And it came to pass that when we had gone up to the land of Jerusalem, I and my brethren did consult one with another. ^verse

---

