And he desired of Laban the records which were engraven upon the plates of brass, which contained the genealogy of my father. ^verse

---

