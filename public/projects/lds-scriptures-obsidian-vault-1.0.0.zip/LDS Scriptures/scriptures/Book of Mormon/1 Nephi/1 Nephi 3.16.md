Wherefore, let us be faithful in keeping the commandments of the Lord; therefore let us go down to the land of our father’s inheritance, for behold he left gold and silver, and all manner of riches. And all this he hath done because of the commandments of the Lord. ^verse

---

