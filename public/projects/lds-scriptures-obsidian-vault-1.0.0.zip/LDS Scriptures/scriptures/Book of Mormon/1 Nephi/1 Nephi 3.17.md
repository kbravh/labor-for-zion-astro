For he knew that Jerusalem must be destroyed, because of the wickedness of the people. ^verse

---

