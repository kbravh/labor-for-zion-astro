For behold, they have rejected the words of the prophets. Wherefore, if my father should dwell in the land after he hath been commanded to flee out of the land, behold, he would also perish. Wherefore, it must needs be that he flee out of the land. ^verse

---

