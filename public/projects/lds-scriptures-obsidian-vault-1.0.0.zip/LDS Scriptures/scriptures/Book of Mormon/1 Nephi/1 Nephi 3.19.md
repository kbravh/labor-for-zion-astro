And behold, it is wisdom in God that we should obtain these records, that we may preserve unto our children the language of our fathers; ^verse

---

