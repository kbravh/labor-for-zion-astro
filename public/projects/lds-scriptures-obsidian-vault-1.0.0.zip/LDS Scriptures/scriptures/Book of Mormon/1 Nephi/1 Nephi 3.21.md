And it came to pass that after this manner of language did I persuade my brethren, that they might be faithful in keeping the commandments of God. ^verse

---

