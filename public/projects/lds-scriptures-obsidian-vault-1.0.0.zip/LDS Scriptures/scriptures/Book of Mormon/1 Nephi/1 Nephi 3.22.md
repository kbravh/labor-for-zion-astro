And it came to pass that we went down to the land of our inheritance, and we did gather together our gold, and our silver, and our precious things. ^verse

---

