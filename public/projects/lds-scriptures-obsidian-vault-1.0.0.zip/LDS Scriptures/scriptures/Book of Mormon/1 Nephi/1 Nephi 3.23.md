And after we had gathered these things together, we went up again unto the house of Laban. ^verse

---

